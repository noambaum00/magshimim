/*********************************
* Class: MAGSHIMIM C2			 *
* Week 10           			 *
* Class Exercise Solution	 	 *
**********************************/

#include <stdio.h>
#include <stdlib.h>

#define STR_LEN 20

typedef struct PersonNode
{
	char name[STR_LEN];
	int age;
	struct PersonNode* next;
} PersonNode;

PersonNode* initPersonNode(void);
PersonNode* createPersonNode(char* name, int age);
void printList(PersonNode* head);
void freeList(PersonNode* next);
int listLength(PersonNode* head);
PersonNode* copyList(PersonNode* head);
void myFgets(char str[], int n);


int main(void)
{
	int people = 0, i = 0;
	PersonNode* head = NULL;
	PersonNode* curr = NULL;
	PersonNode* newList = NULL;
	printf("How many people in the list? ");
	scanf("%d", &people);
	getchar(); // clean buffer
	if (people > 0)
	{
		head = initPersonNode();
		curr = head;
	}
	for (i = 1; i < people; i++)
	{
		curr->next = initPersonNode();
		curr = curr->next;
	}

	printList(head);

	printf("List length: %d\n", listLength(head));

	newList = copyList(head);

	printf("New list:\n");
	printList(newList);

	freeList(head);
	freeList(newList);
	getchar();
	return 0;
}

/*
Function creates PersonNode node
input: none
output: the new node
*/
PersonNode* initPersonNode(void)
{
	char name[STR_LEN] = { 0 };
	int age = 0;
	printf("Enter name: ");
	myFgets(name, STR_LEN);
	printf("Enter age: ");
	scanf("%d", &age);
	getchar(); // clean buffer
	return createPersonNode(name, age);
}

/*
Creates a person node in the memory
input: name and age of person
output: the node in the memory
*/
PersonNode* createPersonNode(char* name, int age)
{
	PersonNode* person = (PersonNode*)malloc(sizeof(PersonNode));
	strncpy(person->name, name, STR_LEN);
	person->age = age;
	person->next = NULL;
	return person;
}
/*
Prints the linked list (recursively!)
input: head of list
output: none
*/
void printList(PersonNode* head)
{
	if (head)
	{
		printf("Name: %s, Age: %d\n", head->name, head->age);
		printList(head->next);
	}
}


/*
Frees list's memory
input: the list to free
output: none
*/
void freeList(PersonNode* head)
{
	PersonNode* temp = head;
	while (head)
	{
		temp = head->next;
		free(head);
		head = temp;
	}
}


/*
Calculates length of list.
input: the list
output: its length
*/
int listLength(PersonNode* head)
{
	int size = 0;
	if (head)
	{
		size = 1 + listLength(head->next);
	}
	return size;
}

/*
Copies list
input: list to copy
output: head of new, copied list
*/
PersonNode* copyList(PersonNode* head)
{
	PersonNode* copyHead = NULL;
	PersonNode* curr = NULL;

	if (head) // list to copy isn't empty
	{
		copyHead = createPersonNode(head->name, head->age);
		curr = copyHead;
		head = head->next;

		while (head)
		{
			curr->next = createPersonNode(head->name, head->age);
			curr = curr->next;
			head = head->next;
		}
	}
	return copyHead;
}


/*
Function will perform the fgets command and also remove the newline
that might be at the end of the string - a known issue with fgets.
input: the buffer to read into, the number of chars to read
*/
void myFgets(char str[], int n)
{
	fgets(str, n, stdin);
	str[strcspn(str, "\n")] = 0;
}