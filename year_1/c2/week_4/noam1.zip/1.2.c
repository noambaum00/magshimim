/*********************************
* Class: MAGSHIMIM C2			 *
* Week:                			 *
* Name:                          *
* Credits:                       *
**********************************/
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>

int main(void)
{
	int size = 7;
	int* grades = NULL;
	scanf('%d', size);
	getchar();
	grades = (int*)malloc(sizeof(int) * size);
	free(grades);
	printf("Leaks: %d", _CrtDumpMemoryLeaks());
	getchar();
	return 0;
}