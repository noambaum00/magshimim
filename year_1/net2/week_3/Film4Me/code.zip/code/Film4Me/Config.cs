namespace Film4Me
{
	internal class Config
	{
		public static string Address { get; }

		public static int Port { get; }

		public static void Init(string configFileName)
		{
		}
	}
}
