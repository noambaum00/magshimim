#include <stdio.h>
int main()
{
	printf("My name is noam and I'm Magshim");
	return 0;
}